Created using Data Curator 0.5.1

- Opened an existing csv
- saved as tsv
- added properties
- exported data package

Suspect tsv wont be handled correctly in exported data package.
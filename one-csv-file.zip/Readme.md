store inventory has 1 csv file in the data package

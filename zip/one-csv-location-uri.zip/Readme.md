Created with Data Curator 0.5.1

A single csv file with location defined by: 

- type: string 
- format: uri

Successfully validated before exporting from Data Curator
Two related tables without a foreign key relationship.

Created by Data Curator v6.0.0 
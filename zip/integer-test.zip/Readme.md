Created with Data Curator 0.5.1

A test for Integer data types to ensure the row and column are returned when an error is detected.
Created with Data Curator 0.5.1

Manually added data package view

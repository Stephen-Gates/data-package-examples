Not created with Data Curator

A test for YearMonth data types, formats and constraints to ensure the row and column are returned when an error is detected.

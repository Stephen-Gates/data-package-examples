Not created with Data Curator

A test for Year data types, formats and constraints to ensure the row and column are returned when an error is detected.

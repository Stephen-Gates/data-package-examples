Created with Data Curator 0.5.1

A single csv file with location defined by:

- type: geopoint
- format: object

Successfully validated before exporting from Data Curator